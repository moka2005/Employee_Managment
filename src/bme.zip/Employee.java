
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mokhtar-mammeri
 */
public class Employee 
{
    JFrame frame ;
    DefaultTableModel model = new DefaultTableModel();
    
    Employee()
    {
        frame = new JFrame();
        frame.setSize(1000,700);
        
        frame.setLocationRelativeTo(null);
        creat_interfacGraphics();
        frame.setVisible(true);
    }
    public void creat_interfacGraphics()
    {
        frame.setLayout(new BorderLayout());
        
        JPanel North = new JPanel();
        North.setLayout(new BorderLayout());
        
        
        North.setPreferredSize(new Dimension(frame.getWidth(),200));
         
        JLabel label_head = new JLabel("العمال");
        label_head.setHorizontalAlignment(SwingConstants.CENTER);
        label_head.setVerticalAlignment(SwingConstants.CENTER);
        Font f1 = new Font("Arial", Font.BOLD, 35);
        label_head.setFont(f1);
        North.setBackground(Color.red);
       
        North.add(label_head,BorderLayout.CENTER);
        frame.add(North,BorderLayout.NORTH);
        
        
        
        JPanel south = new JPanel();
        south.setPreferredSize(new Dimension(frame.getWidth(),200));
        south.setLayout(new FlowLayout(FlowLayout.CENTER));
        south.setPreferredSize(new Dimension(frame.getWidth(),50));
       
        frame.add(south,BorderLayout.SOUTH);
        
        JButton insert = new JButton("إضافة عامل");
        JButton Delete = new JButton("حذف عامل");
        insert.setBackground(Color.white);
        Delete.setBackground(Color.white);
        insert.setPreferredSize(new Dimension(200,40));
        Delete.setPreferredSize(new Dimension(200,40));
        //insert.setBorderPainted(false);
        insert.setFocusPainted(false);
        Delete.setFocusPainted(false);
        
        south.add(insert);
        south.add(Delete);
        
        model.addColumn("id_Employee");
        model.addColumn("nom");
        model.addColumn("prenom");
        model.addColumn("date_naissance");
        model.addColumn("date_embauche");
        model.addColumn("telephone");
        model.addColumn("post");
        model.addColumn("salaire");
        model.addColumn("etat");
        
        
       

     
        JTable table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
            
            return false;
            }
        };
         try {
            String selectSQL = "SELECT * FROM Employee";
            ResultSet rs = DataBaseMangemet.select_Query(selectSQL);
            
            // إضافة البيانات إلى الجدول 
            while (rs.next()) {
                Vector<String> row = new Vector<>();
                row.add(rs.getString("id_Employee"));
                row.add(rs.getString("nom"));
                row.add(rs.getString("date_naissance"));
                row.add(rs.getString("date_embauche"));
                row.add(rs.getString("telephone"));
                row.add(rs.getString("post"));
                row.add(rs.getString("salaire"));
                row.add(rs.getString("etat"));
                model.addRow(row);
            }
            
            DataBaseMangemet.conn.close();
        } catch (SQLException e2) {System.out.println(e2.getMessage());}
        
        Font f2 = new Font("Arial", Font.BOLD, 15);
        table.setRowHeight(40);
        table.setFont(f2);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.setDefaultRenderer(Object.class, centerRenderer);
        JTableHeader header = table.getTableHeader();
        header.setFont(f2);
        header.setBackground(Color.BLUE);
        header.setForeground(Color.WHITE);
        


      
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane,BorderLayout.CENTER);

        
        
    }
    public static void main(String[]args)
    {
        Employee e = new Employee();
    }        
    
    
    
}
